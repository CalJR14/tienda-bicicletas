const CONFIG_BD = {
    user: 'postgres',
    host: 'localhost',
    database: 'productos',
    password: 'admin',
    port: 5432 //puerto predeterminado de PostgreSQL
}

module.exports = {
    CONFIG_BD,
};